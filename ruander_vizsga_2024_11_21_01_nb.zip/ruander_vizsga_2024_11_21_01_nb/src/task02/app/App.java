package task02.app;

public class App {

	public static void main(String[] args) {
		ElectricScooter es = new ElectricScooter("BestElectricRoller4U", 2022, "fekete", "M-531", 10000, 25);
                System.out.println(es.toString());
	}
}
