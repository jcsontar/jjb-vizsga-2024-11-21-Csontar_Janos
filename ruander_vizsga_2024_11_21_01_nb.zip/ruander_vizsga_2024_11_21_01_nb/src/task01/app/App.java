package task01.app;

import java.time.LocalDate;
import java.time.Month;
import java.util.Scanner;

public class App {

	public static void main(String[] args) {
           

	}

       static  public int calculateAge(LocalDate date){
            int result;
            LocalDate today = LocalDate.now();
            int dayOfBirth = date.getDayOfYear();
            int dayOfThisYear = today.getDayOfYear();
            result = today.getYear() - date.getYear();
            if(dayOfBirth > dayOfThisYear){
                result--;
            }
            return result;
        }
}
