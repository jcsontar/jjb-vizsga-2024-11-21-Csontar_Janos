package task03.app;

import java.util.HashMap;
import java.util.Map;

public class App {

	public static void main(String[] args) {
            Food bol = new Food("Pizza bolognese", (double)3900, false);
            Food haw = new Food("Hawaii pizza", (double)4500, true);
            OrderItem orderItemFirst = new OrderItem(bol, 2);
            OrderItem orderItemSecond = new OrderItem(haw, 1);
            Map map = new HashMap();
            map.put(1, orderItemFirst);
            map.put(2, orderItemSecond);
            long orderId = (long)1;
            Order order = new Order(orderId, map);
            System.out.println("A rendelés azonosítója: " + order.getId() +", teljes összeg : " +
                    order.getTotalCost());
            
	}
}
