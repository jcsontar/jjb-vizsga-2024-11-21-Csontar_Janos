package task03.app;

import java.util.Map;

public class Order {

	private Long id;
	private Map<Integer, OrderItem> orderItems;
	
	public Order(Long id, Map<Integer, OrderItem> map) {
		this.id = id;
		this.orderItems = map;
	}
	
	public Map<Integer, OrderItem> getOrderItems() {
		return orderItems;
	}
	
	public Long getId() {
		return id;
	}
        
        public Double getTotalCost(){
            double result = 0;
            OrderItem item;
            boolean sale;
            for(int i = 1; i < orderItems.size() + 1; i++){
                item = orderItems.get(i);
                sale = item.getFood().isSale();
                if(!sale){
                result += item.getQuantity() * item.getFood().getNetPrice();
                } else {
                    result += item.getQuantity() * item.getFood().getDiscountedPrice();
                }
            }
            return result;
        }
}
