package task04.app;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class App {

    public static void main(String[] args) throws FileNotFoundException {
        List<String> shoes = readFile("fit.shoes.csv");
    //    List<FootWear> footWears = makeFootWears(shoes);
    }

    private static List<String> readFile(String s) throws FileNotFoundException {
        List<String> shoes = new ArrayList<>();
        FileReader fileReader = new FileReader(s);
        BufferedReader reader = new BufferedReader(fileReader);
        s = "";
        try {
            while (reader.readLine() != null) {
                s = reader.readLine();
                shoes.add(s);
                
            }
        } catch (IOException ex) {
            Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
        }
        return shoes;
    }

//    private static List<FootWear> makeFootWears(List<String> shoes) {
//        
//        for(int i = 0; i < shoes.size(); i++){
//            
//        }
//    }
}
