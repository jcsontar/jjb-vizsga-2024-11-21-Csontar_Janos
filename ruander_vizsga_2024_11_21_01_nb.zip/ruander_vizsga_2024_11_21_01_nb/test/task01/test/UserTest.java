package task01.test;

import java.time.LocalDate;
import org.junit.Assert;
import org.junit.Test;
import task01.app.App;
import task01.app.User;

public class UserTest {

    @Test
    public void testUserStatusText() {
        User user = new User("Elek", "Teszt", "tesztelek", LocalDate.
                of(1999, 01, 01), true);
        String actual = user.getStatusText();
        String expected = "aktív";

        Assert.assertEquals(expected, actual);
        int expectedAge = 25;
        int actualAge = App.calculateAge(user.getDateOfBirth());
        Assert.assertEquals(expectedAge, actualAge);
        
        String expectedUserName = "tesztelek";
        String actualUsername = user.getUserName();
        Assert.assertEquals(actualUsername, actualUsername);
        
        boolean expectedStatus = true;
        boolean actualStatus = user.getStatus();
        Assert.assertEquals(expectedStatus, actualStatus);
    }
}
