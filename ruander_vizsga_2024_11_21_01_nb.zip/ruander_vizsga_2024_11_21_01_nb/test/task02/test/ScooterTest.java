package task02.test;

import org.junit.Assert;
import org.junit.Test;
import task02.app.Scooter;

public class ScooterTest {

    @Test
    public void isOldTest() {
        
        Scooter scooter = new Scooter("BestScooterFor4U", 2020, "fehér",
                "TRE-4456");
        Boolean actual = scooter.isOld();
        Boolean expected = false;
        Assert.assertEquals(expected, actual);
        
        String expectedColor = "fehér";
        String actualColor = scooter.getColor();
        Assert.assertEquals(expectedColor, actualColor);
        
        String expectedModel = "TRE-4456";
        String actualModel = scooter.getModel();
        Assert.assertEquals(expectedModel, actualModel);
        
    }
}
